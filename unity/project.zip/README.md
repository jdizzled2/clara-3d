# Steps to export and convert tiles

1. Find tiles in Assets\Low Poly Tiles\Prefabs\Grass
2. Drag and drop the tile to the scene view or Hierarchy
3. Right click on the imported tile in the hierarchy and click on "Export to FBX"
4. Tile sits now in your "Assets" folder
5. download the following application "https://github.com/facebookincubator/FBX2glTF/releases/download/v0.9.7/FBX2glTF-windows-x64.exe"
6. Copy that exe file to your Assets folder
7. Run following command `./FBX2glTF-darwin-x64 -b <name_of_the_exported.fbx>`
8. This outputs your GLB
9. Test it at https://gltf.insimo.com
